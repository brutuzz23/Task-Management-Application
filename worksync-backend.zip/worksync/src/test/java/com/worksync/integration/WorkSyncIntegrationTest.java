package com.worksync.integration;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

@SpringBootTest
@AutoConfigureMockMvc
@Testcontainers
class WorkSyncIntegrationTest {

    @Container
    static final PostgreSQLContainer<?> POSTGRES = new PostgreSQLContainer<>("postgres:16-alpine");

    @DynamicPropertySource
    static void datasource(DynamicPropertyRegistry registry) {
        registry.add("spring.datasource.url", POSTGRES::getJdbcUrl);
        registry.add("spring.datasource.username", POSTGRES::getUsername);
        registry.add("spring.datasource.password", POSTGRES::getPassword);
    }

    @Autowired MockMvc mvc;
    @Autowired ObjectMapper json;
    @Autowired JdbcTemplate jdbc;
    @MockBean JavaMailSender mailSender;

    // ---------- helpers ----------

    private JsonNode post(String url, String token, Object body, int expectedStatus) throws Exception {
        var req = post(url).contentType(MediaType.APPLICATION_JSON).content(json.writeValueAsString(body));
        if (token != null) req.header("Authorization", "Bearer " + token);
        String content = mvc.perform(req).andExpect(status().is(expectedStatus)).andReturn().getResponse().getContentAsString();
        return content.isBlank() ? null : json.readTree(content);
    }

    private String register(String email) throws Exception {
        return post("/api/auth/register", null, Map.of("email", email, "password", "password123"), 201)
                .get("token").asText();
    }

    private String newEmail() {
        return "user-" + UUID.randomUUID() + "@example.com";
    }

    private String createBoard(String token) throws Exception {
        return post("/api/boards", token, Map.of("name", "Sprint 1"), 201).get("id").asText();
    }

    // ---------- tests ----------

    @Test
    void protectedEndpointsRequireAuthentication() throws Exception {
        mvc.perform(get("/api/boards")).andExpect(status().isUnauthorized());
        mvc.perform(get("/api/boards").header("Authorization", "Bearer not-a-jwt")).andExpect(status().isUnauthorized());
    }

    @Test
    void registerLoginAndDuplicateEmail() throws Exception {
        String email = newEmail();
        register(email);

        post("/api/auth/register", null, Map.of("email", email, "password", "password123"), 409);
        post("/api/auth/login", null, Map.of("email", email, "password", "wrong-password"), 401);
        JsonNode login = post("/api/auth/login", null, Map.of("email", email, "password", "password123"), 200);
        assertThat(login.get("token").asText()).isNotBlank();
    }

    @Test
    void validationErrorsReturn400() throws Exception {
        post("/api/auth/register", null, Map.of("email", "not-an-email", "password", "short"), 400);
    }

    @Test
    void boardAndTaskCrudWithOwnerOnlyAccess() throws Exception {
        String owner = register(newEmail());
        String intruder = register(newEmail());
        String boardId = createBoard(owner);

        JsonNode task = post("/api/boards/" + boardId + "/tasks", owner, Map.of("title", "Write docs"), 201);
        String taskId = task.get("id").asText();
        assertThat(task.get("status").asText()).isEqualTo("TODO");

        // update status
        mvc.perform(put("/api/boards/" + boardId + "/tasks/" + taskId)
                        .header("Authorization", "Bearer " + owner)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json.writeValueAsString(Map.of("title", "Write docs", "status", "DONE"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("DONE"));

        // filter by status
        mvc.perform(get("/api/boards/" + boardId + "/tasks?status=TODO").header("Authorization", "Bearer " + owner))
                .andExpect(status().isOk()).andExpect(jsonPath("$.length()").value(0));

        // another user can't see, list, create in, or delete the owner's resources
        mvc.perform(get("/api/boards/" + boardId).header("Authorization", "Bearer " + intruder))
                .andExpect(status().isNotFound());
        mvc.perform(get("/api/boards/" + boardId + "/tasks").header("Authorization", "Bearer " + intruder))
                .andExpect(status().isNotFound());
        post("/api/boards/" + boardId + "/tasks", intruder, Map.of("title", "sneaky"), 404);
        mvc.perform(delete("/api/boards/" + boardId + "/tasks/" + taskId).header("Authorization", "Bearer " + intruder))
                .andExpect(status().isNotFound());
        mvc.perform(get("/api/boards").header("Authorization", "Bearer " + intruder))
                .andExpect(status().isOk()).andExpect(jsonPath("$.length()").value(0));
    }

    @Test
    void deletesAreSoftAndBoardDeleteCascadesToTasks() throws Exception {
        String owner = register(newEmail());
        String boardId = createBoard(owner);
        String taskA = post("/api/boards/" + boardId + "/tasks", owner, Map.of("title", "A"), 201).get("id").asText();
        String taskB = post("/api/boards/" + boardId + "/tasks", owner, Map.of("title", "B"), 201).get("id").asText();

        mvc.perform(delete("/api/boards/" + boardId + "/tasks/" + taskA).header("Authorization", "Bearer " + owner))
                .andExpect(status().isNoContent());
        mvc.perform(get("/api/boards/" + boardId + "/tasks/" + taskA).header("Authorization", "Bearer " + owner))
                .andExpect(status().isNotFound());
        assertThat(softDeleted("tasks", taskA)).isTrue();

        mvc.perform(delete("/api/boards/" + boardId).header("Authorization", "Bearer " + owner))
                .andExpect(status().isNoContent());
        mvc.perform(get("/api/boards/" + boardId).header("Authorization", "Bearer " + owner))
                .andExpect(status().isNotFound());
        assertThat(softDeleted("boards", boardId)).isTrue();
        assertThat(softDeleted("tasks", taskB)).isTrue();
    }

    @Test
    void passwordRecoveryFlow() throws Exception {
        String email = newEmail();
        register(email);

        post("/api/auth/forgot-password", null, Map.of("email", email), 202);
        // unknown emails get the same response and no email
        post("/api/auth/forgot-password", null, Map.of("email", newEmail()), 202);

        ArgumentCaptor<SimpleMailMessage> mail = ArgumentCaptor.forClass(SimpleMailMessage.class);
        verify(mailSender).send(mail.capture());
        Matcher m = Pattern.compile("token=([A-Za-z0-9_-]+)").matcher(mail.getValue().getText());
        assertThat(m.find()).isTrue();
        String token = m.group(1);

        post("/api/auth/reset-password", null, Map.of("token", "bogus", "newPassword", "new-password-1"), 400);
        post("/api/auth/reset-password", null, Map.of("token", token, "newPassword", "new-password-1"), 204);
        // token is single-use
        post("/api/auth/reset-password", null, Map.of("token", token, "newPassword", "new-password-2"), 400);

        post("/api/auth/login", null, Map.of("email", email, "password", "password123"), 401);
        post("/api/auth/login", null, Map.of("email", email, "password", "new-password-1"), 200);
    }

    private boolean softDeleted(String table, String id) {
        Integer count = jdbc.queryForObject(
                "select count(*) from " + table + " where id = ? and deleted_at is not null",
                Integer.class, UUID.fromString(id));
        return count != null && count == 1;
    }
}
