package com.worksync.security;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.util.UUID;
import org.junit.jupiter.api.Test;

class JwtServiceTest {

    private static final String SECRET = "test-secret-test-secret-test-secret-123456";

    @Test
    void roundTripReturnsUserId() {
        JwtService jwt = new JwtService(SECRET, 5);
        UUID id = UUID.randomUUID();

        String token = jwt.generateToken(id, "a@b.com");

        assertThat(jwt.validateAndGetUserId(token)).contains(id);
    }

    @Test
    void rejectsTamperedToken() {
        JwtService jwt = new JwtService(SECRET, 5);
        String token = jwt.generateToken(UUID.randomUUID(), "a@b.com");

        assertThat(jwt.validateAndGetUserId(token + "x")).isEmpty();
    }

    @Test
    void rejectsTokenSignedWithAnotherKey() {
        JwtService other = new JwtService("another-secret-another-secret-another-1234", 5);
        JwtService jwt = new JwtService(SECRET, 5);

        assertThat(jwt.validateAndGetUserId(other.generateToken(UUID.randomUUID(), "a@b.com"))).isEmpty();
    }

    @Test
    void rejectsExpiredToken() {
        JwtService jwt = new JwtService(SECRET, -1);

        assertThat(jwt.validateAndGetUserId(jwt.generateToken(UUID.randomUUID(), "a@b.com"))).isEmpty();
    }

    @Test
    void rejectsShortSecret() {
        assertThatThrownBy(() -> new JwtService("too-short", 5)).isInstanceOf(IllegalStateException.class);
    }
}
