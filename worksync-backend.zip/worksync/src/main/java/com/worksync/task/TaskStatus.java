package com.worksync.task;

public enum TaskStatus { TODO, IN_PROGRESS, DONE }
