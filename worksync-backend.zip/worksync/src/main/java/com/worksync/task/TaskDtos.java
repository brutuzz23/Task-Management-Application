package com.worksync.task;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.time.Instant;
import java.time.LocalDate;
import java.util.UUID;

public final class TaskDtos {
    private TaskDtos() {}

    public record CreateTaskRequest(
            @NotBlank @Size(max = 200) String title,
            @Size(max = 5000) String description,
            TaskStatus status,
            LocalDate dueDate) {}

    public record UpdateTaskRequest(
            @NotBlank @Size(max = 200) String title,
            @Size(max = 5000) String description,
            @NotNull TaskStatus status,
            LocalDate dueDate) {}

    public record TaskResponse(UUID id, UUID boardId, String title, String description, TaskStatus status,
                               LocalDate dueDate, Instant createdAt, Instant updatedAt) {
        public static TaskResponse from(Task t) {
            return new TaskResponse(t.getId(), t.getBoardId(), t.getTitle(), t.getDescription(),
                    t.getStatus(), t.getDueDate(), t.getCreatedAt(), t.getUpdatedAt());
        }
    }
}
