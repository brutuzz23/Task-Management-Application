package com.worksync.task;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface TaskRepository extends JpaRepository<Task, UUID> {

    List<Task> findByBoardIdOrderByCreatedAtAsc(UUID boardId);

    List<Task> findByBoardIdAndStatusOrderByCreatedAtAsc(UUID boardId, TaskStatus status);

    Optional<Task> findByIdAndBoardId(UUID id, UUID boardId);

    /** Cascades a board's soft deletion to its tasks. */
    @Modifying
    @Query(value = "UPDATE tasks SET deleted_at = now() WHERE board_id = :boardId AND deleted_at IS NULL",
           nativeQuery = true)
    int softDeleteByBoardId(@Param("boardId") UUID boardId);
}
