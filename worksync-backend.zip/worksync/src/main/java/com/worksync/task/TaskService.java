package com.worksync.task;

import com.worksync.board.BoardService;
import com.worksync.common.NotFoundException;
import com.worksync.task.TaskDtos.*;
import java.util.List;
import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class TaskService {

    private final TaskRepository tasks;
    private final BoardService boards;

    public TaskService(TaskRepository tasks, BoardService boards) {
        this.tasks = tasks;
        this.boards = boards;
    }

    @Transactional(readOnly = true)
    public List<Task> list(UUID userId, UUID boardId, TaskStatus status) {
        boards.getOwned(boardId, userId);
        return status == null
                ? tasks.findByBoardIdOrderByCreatedAtAsc(boardId)
                : tasks.findByBoardIdAndStatusOrderByCreatedAtAsc(boardId, status);
    }

    @Transactional
    public Task create(UUID userId, UUID boardId, CreateTaskRequest req) {
        boards.getOwned(boardId, userId);
        TaskStatus status = req.status() != null ? req.status() : TaskStatus.TODO;
        return tasks.save(new Task(boardId, req.title(), req.description(), status, req.dueDate()));
    }

    @Transactional(readOnly = true)
    public Task get(UUID userId, UUID boardId, UUID taskId) {
        boards.getOwned(boardId, userId);
        return tasks.findByIdAndBoardId(taskId, boardId)
                .orElseThrow(() -> new NotFoundException("Task not found"));
    }

    @Transactional
    public Task update(UUID userId, UUID boardId, UUID taskId, UpdateTaskRequest req) {
        Task task = get(userId, boardId, taskId);
        task.update(req.title(), req.description(), req.status(), req.dueDate());
        return task;
    }

    @Transactional
    public void delete(UUID userId, UUID boardId, UUID taskId) {
        tasks.delete(get(userId, boardId, taskId));
    }
}
