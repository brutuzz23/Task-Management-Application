package com.worksync.task;

import com.worksync.task.TaskDtos.*;
import jakarta.validation.Valid;
import java.util.List;
import java.util.UUID;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/boards/{boardId}/tasks")
public class TaskController {

    private final TaskService service;

    public TaskController(TaskService service) {
        this.service = service;
    }

    @GetMapping
    public List<TaskResponse> list(@AuthenticationPrincipal UUID userId, @PathVariable UUID boardId,
                                   @RequestParam(required = false) TaskStatus status) {
        return service.list(userId, boardId, status).stream().map(TaskResponse::from).toList();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public TaskResponse create(@AuthenticationPrincipal UUID userId, @PathVariable UUID boardId,
                               @Valid @RequestBody CreateTaskRequest req) {
        return TaskResponse.from(service.create(userId, boardId, req));
    }

    @GetMapping("/{taskId}")
    public TaskResponse get(@AuthenticationPrincipal UUID userId, @PathVariable UUID boardId,
                            @PathVariable UUID taskId) {
        return TaskResponse.from(service.get(userId, boardId, taskId));
    }

    @PutMapping("/{taskId}")
    public TaskResponse update(@AuthenticationPrincipal UUID userId, @PathVariable UUID boardId,
                               @PathVariable UUID taskId, @Valid @RequestBody UpdateTaskRequest req) {
        return TaskResponse.from(service.update(userId, boardId, taskId, req));
    }

    @DeleteMapping("/{taskId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@AuthenticationPrincipal UUID userId, @PathVariable UUID boardId,
                       @PathVariable UUID taskId) {
        service.delete(userId, boardId, taskId);
    }
}
