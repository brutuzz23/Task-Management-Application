package com.worksync.common;

public class NotFoundException extends RuntimeException {
    public NotFoundException(String message) { super(message); }
}
