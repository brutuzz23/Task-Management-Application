package com.worksync.common;

public class ConflictException extends RuntimeException {
    public ConflictException(String message) { super(message); }
}
