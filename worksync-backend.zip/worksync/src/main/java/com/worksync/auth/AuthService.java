package com.worksync.auth;

import com.worksync.auth.AuthDtos.*;
import com.worksync.common.BadRequestException;
import com.worksync.common.ConflictException;
import com.worksync.common.UnauthorizedException;
import com.worksync.security.JwtService;
import com.worksync.user.User;
import com.worksync.user.UserRepository;
import java.time.Duration;
import java.time.Instant;
import java.util.Locale;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mail.MailException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AuthService {

    private static final Logger log = LoggerFactory.getLogger(AuthService.class);
    private static final Duration RESET_TOKEN_TTL = Duration.ofMinutes(30);

    private final UserRepository users;
    private final PasswordResetTokenRepository resetTokens;
    private final PasswordEncoder encoder;
    private final JwtService jwtService;
    private final MailService mailService;

    public AuthService(UserRepository users, PasswordResetTokenRepository resetTokens,
                       PasswordEncoder encoder, JwtService jwtService, MailService mailService) {
        this.users = users;
        this.resetTokens = resetTokens;
        this.encoder = encoder;
        this.jwtService = jwtService;
        this.mailService = mailService;
    }

    @Transactional
    public AuthResponse register(RegisterRequest req) {
        String email = normalize(req.email());
        if (users.existsByEmail(email)) {
            throw new ConflictException("Email is already registered");
        }
        User user = users.save(new User(email, encoder.encode(req.password())));
        return toResponse(user);
    }

    @Transactional(readOnly = true)
    public AuthResponse login(LoginRequest req) {
        User user = users.findByEmail(normalize(req.email()))
                .filter(u -> encoder.matches(req.password(), u.getPasswordHash()))
                .orElseThrow(() -> new UnauthorizedException("Invalid email or password"));
        return toResponse(user);
    }

    /** Always succeeds from the caller's point of view, so it can't be used to probe which emails exist. */
    @Transactional
    public void requestPasswordReset(String rawEmail) {
        users.findByEmail(normalize(rawEmail)).ifPresent(user -> {
            resetTokens.deleteByUserId(user.getId());
            String rawToken = TokenUtil.generate();
            resetTokens.save(new PasswordResetToken(
                    user.getId(), TokenUtil.sha256(rawToken), Instant.now().plus(RESET_TOKEN_TTL)));
            try {
                mailService.sendPasswordReset(user.getEmail(), rawToken);
            } catch (MailException e) {
                log.warn("Could not send password reset email: {}", e.getMessage());
            }
        });
    }

    @Transactional
    public void resetPassword(ResetPasswordRequest req) {
        PasswordResetToken token = resetTokens.findByTokenHash(TokenUtil.sha256(req.token()))
                .filter(PasswordResetToken::isUsable)
                .orElseThrow(() -> new BadRequestException("Invalid or expired reset token"));
        User user = users.findById(token.getUserId())
                .orElseThrow(() -> new BadRequestException("Invalid or expired reset token"));
        user.setPasswordHash(encoder.encode(req.newPassword()));
        token.markUsed();
    }

    private AuthResponse toResponse(User user) {
        return new AuthResponse(jwtService.generateToken(user.getId(), user.getEmail()), user.getId(), user.getEmail());
    }

    private static String normalize(String email) {
        return email.trim().toLowerCase(Locale.ROOT);
    }
}
