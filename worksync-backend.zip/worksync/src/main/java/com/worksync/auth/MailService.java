package com.worksync.auth;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class MailService {

    private final JavaMailSender mailSender;
    private final String from;
    private final String frontendUrl;

    public MailService(JavaMailSender mailSender,
                       @Value("${app.mail.from}") String from,
                       @Value("${app.frontend-url}") String frontendUrl) {
        this.mailSender = mailSender;
        this.from = from;
        this.frontendUrl = frontendUrl;
    }

    public void sendPasswordReset(String to, String rawToken) {
        SimpleMailMessage msg = new SimpleMailMessage();
        msg.setFrom(from);
        msg.setTo(to);
        msg.setSubject("Reset your WorkSync password");
        msg.setText("""
                We received a request to reset your WorkSync password.

                Use the link below within 30 minutes:
                %s/reset-password?token=%s

                If you didn't request this, you can safely ignore this email.
                """.formatted(frontendUrl, rawToken));
        mailSender.send(msg);
    }
}
