package com.worksync.board;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import java.time.Instant;
import java.util.UUID;

public final class BoardDtos {
    private BoardDtos() {}

    public record BoardRequest(
            @NotBlank @Size(max = 120) String name,
            @Size(max = 5000) String description) {}

    public record BoardResponse(UUID id, String name, String description, Instant createdAt, Instant updatedAt) {
        public static BoardResponse from(Board b) {
            return new BoardResponse(b.getId(), b.getName(), b.getDescription(), b.getCreatedAt(), b.getUpdatedAt());
        }
    }
}
