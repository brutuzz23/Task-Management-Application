package com.worksync.board;

import com.worksync.common.NotFoundException;
import com.worksync.task.TaskRepository;
import java.util.List;
import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class BoardService {

    private final BoardRepository boards;
    private final TaskRepository tasks;

    public BoardService(BoardRepository boards, TaskRepository tasks) {
        this.boards = boards;
        this.tasks = tasks;
    }

    /**
     * Access control: a board is only visible to its owner. Anything else returns 404
     * (not 403) so board ids can't be probed.
     */
    @Transactional(readOnly = true)
    public Board getOwned(UUID boardId, UUID userId) {
        return boards.findByIdAndOwnerId(boardId, userId)
                .orElseThrow(() -> new NotFoundException("Board not found"));
    }

    @Transactional(readOnly = true)
    public List<Board> list(UUID userId) {
        return boards.findByOwnerIdOrderByCreatedAtDesc(userId);
    }

    @Transactional
    public Board create(UUID userId, String name, String description) {
        return boards.save(new Board(userId, name, description));
    }

    @Transactional
    public Board update(UUID userId, UUID boardId, String name, String description) {
        Board board = getOwned(boardId, userId);
        board.update(name, description);
        return board;
    }

    @Transactional
    public void delete(UUID userId, UUID boardId) {
        Board board = getOwned(boardId, userId);
        tasks.softDeleteByBoardId(board.getId());
        boards.delete(board);
    }
}
