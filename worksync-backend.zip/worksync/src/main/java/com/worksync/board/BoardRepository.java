package com.worksync.board;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BoardRepository extends JpaRepository<Board, UUID> {
    List<Board> findByOwnerIdOrderByCreatedAtDesc(UUID ownerId);
    Optional<Board> findByIdAndOwnerId(UUID id, UUID ownerId);
}
