package com.worksync.board;

import com.worksync.board.BoardDtos.*;
import jakarta.validation.Valid;
import java.util.List;
import java.util.UUID;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/boards")
public class BoardController {

    private final BoardService service;

    public BoardController(BoardService service) {
        this.service = service;
    }

    @GetMapping
    public List<BoardResponse> list(@AuthenticationPrincipal UUID userId) {
        return service.list(userId).stream().map(BoardResponse::from).toList();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public BoardResponse create(@AuthenticationPrincipal UUID userId, @Valid @RequestBody BoardRequest req) {
        return BoardResponse.from(service.create(userId, req.name(), req.description()));
    }

    @GetMapping("/{boardId}")
    public BoardResponse get(@AuthenticationPrincipal UUID userId, @PathVariable UUID boardId) {
        return BoardResponse.from(service.getOwned(boardId, userId));
    }

    @PutMapping("/{boardId}")
    public BoardResponse update(@AuthenticationPrincipal UUID userId, @PathVariable UUID boardId,
                                @Valid @RequestBody BoardRequest req) {
        return BoardResponse.from(service.update(userId, boardId, req.name(), req.description()));
    }

    @DeleteMapping("/{boardId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@AuthenticationPrincipal UUID userId, @PathVariable UUID boardId) {
        service.delete(userId, boardId);
    }
}
